# 全壘打大作戰 — Cloudflare Pages 部署包

這是純靜態 HTML/CSS/JavaScript 遊戲，無需資料庫、帳號、額外套件或建置程序。適合國小高年級到國一，單次遊戲約 3–5 分鐘。

## Cloudflare Pages 部署（直接上傳）
1. 解壓縮 `homerun-cloudflare.zip`。
2. 登入 Cloudflare Dashboard，前往 **Workers & Pages**，建立 **Pages** 專案，選擇 **Direct Upload / Upload assets**（介面文字可能更新）。
3. 將解壓縮後 `homerun-cloudflare` 資料夾中的全部檔案拖入上傳區（請確保 `index.html` 在部署根目錄），按下部署。
4. 完成後開啟 Cloudflare 提供的 `*.pages.dev` 網址即可遊玩。

如果你的 Cloudflare 帳號介面引導至 Workers，也可使用其靜態資源上傳部署；核心要求是將 `index.html`、`style.css`、`game.js`、`_headers` 放在網站根目錄。

## 本機預覽
使用 VS Code Live Server 開啟 `index.html`，或在本資料夾執行 `python -m http.server 8000`，瀏覽 `http://localhost:8000`。

## 內容與調整
- 關卡：練習場、高牆、遠牆。每關最多 5 次揮棒，可無限重新挑戰。
- 角度與力道滑桿、棒球飛行動畫、結果回饋、通關總結。
- 沒有結尾知識問答。
- 更改關卡：編輯 `game.js` 中的 `LEVELS` 陣列。
- 使用簡化的飛行模型；球場牆高與距離為**教學模擬數據**，不代表真實球場。
- 不包含第三方分析腳本，不收集使用者個資。
